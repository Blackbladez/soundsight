// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	/// <summary>
	/// Tiles consist of these Tile Pieces. One of the pieces, normally a floor piece but walls also possible, 
	/// will act as the container for aditional pieces ion the same tile spot which will be saved in linkedPieces.
	/// </summary>
	[AddComponentMenu("UniRPG/Tile Piece")]
	public class TilePiece : MonoBehaviour
	{
		public enum Direction : int { Invalid = -1, Up = 0, Right = 90, Down = 180, Left = 270, UpR = 45, UpL = 315, DwnL = 225, DwnR = 135 }
		public enum Kind : int { 
			None = -1, 
			Floor = 0, Wall = 1, Corner1 = 2, Corner2 = 3, Corner3 = 4, Pillar = 5,
			
			Single = 0, Full = 1, /*Corner1 = 2, Corner2 = 3,*/ Sides = 4, One_Side = 5, Dead_End = 6,
			Junction1 = 7, Junction2 = 8, Junction3 = 9,
			Crossing1 = 10, Crossing2 = 11, Crossing3 = 12, Crossing4 = 13, Crossing5 = 14,
		}

		[HideInInspector] public Kind kind = Kind.None;	// kind of tile piece
		[HideInInspector] public Direction faceDir = Direction.Up;
		[HideInInspector] public int setIdx = 0;		// index into tileset this tile piece came from
		[HideInInspector] public int tileIdx = 0;		// index into tile (in set) this piece came from 
		[HideInInspector] public int floorLevel = 0;	// floor level of this piece

		// the pieces that share the same tile space with this piece (when this piece act as the main piece of the tile)
		[HideInInspector] public List<GameObject> linkedPieces = null;

		/// <summary>Preview image of the tile piece. Don't use, it is not inited at runtime and only used by Editor as a cache</summary>
		[System.NonSerialized] public Texture2D _preview = null;

		// ================================================================================================================
	}
}