// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	[System.Serializable]
	public class DefAutoTileSet
	{
		public string name = "TileSet";									// name of this set
		public Color editorColor = Color.cyan;							// colour used in editor
		public UniRPG.TileSetKind kind = UniRPG.TileSetKind.Terrain;	// the kind of tileset
		public bool isLower = false;									// a special lower type tile, for example a Water/Lava/Pit tile in a Dungeon

		// the maps this tile-set is allowed on
		public UniRPG.MapKind allowedMapsMask = UniRPG.MapKind.Terrain;

		// the tiles in this set (TilePiece)
		public List<DefAutoTile> tiles = new List<DefAutoTile>();
	}
}