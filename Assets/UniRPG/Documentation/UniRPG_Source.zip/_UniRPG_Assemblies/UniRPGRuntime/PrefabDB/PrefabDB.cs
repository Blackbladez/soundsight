// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	/// <summary>
	/// Container for all the prefabs used in UniRPG maps
	/// </summary>
	public class PrefabDB : MonoBehaviour
	{
		public List<DefTileSet> tiles = new List<DefTileSet>();					// definitions for normal tile sets
		public List<DefAutoTileSet> autoTiles = new List<DefAutoTileSet>();		// definitions for auto-tile sets
		public List<DefPlopSet> plopSets = new List<DefPlopSet>();				// definitions for items that can be placed

		// ================================================================================================================
	}
}