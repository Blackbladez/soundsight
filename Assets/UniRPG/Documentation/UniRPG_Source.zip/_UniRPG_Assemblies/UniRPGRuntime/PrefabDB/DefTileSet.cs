// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	[System.Serializable]
	public class DefTileSet
	{
		public string name = "TileSet";								// name of this set
		public Color editorColor = Color.cyan;						// colour used in editor
		public UniRPG.TileSetKind kind = UniRPG.TileSetKind.Single;	// the kind of tileset (where it can be used)

		// the maps this tile-set is allowed on
		public UniRPG.MapKind allowedMapsMask = (UniRPG.MapKind.Dungeon | UniRPG.MapKind.Terrain);

		// the tiles in this set (TilePiece)
		public List<GameObject> tiles = new List<GameObject>();
	}
}