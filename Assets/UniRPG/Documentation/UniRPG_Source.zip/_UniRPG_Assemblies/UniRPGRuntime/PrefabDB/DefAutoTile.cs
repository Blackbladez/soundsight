// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;

namespace UniRPGRuntime
{
	[System.Serializable]
	public class DefAutoTile
	{
		public static int DUNGEON_MAX_PIECES = 6;
		public static int TERRAIN_MAX_PIECES = 4;
		public static int EXPANDING_MAX_PIECES = 15;

		public GameObject[] pieces;

		public int upperSet = -1;
		public int upperTile = -1;

		public DefAutoTile(int piecesCount)
		{
			pieces = new GameObject[piecesCount];
		}

		public DefAutoTile Clone()
		{
			DefAutoTile t = new DefAutoTile(this.pieces.Length);
			for (int i = 0; i < this.pieces.Length; i++)
			{
				t.pieces[i] = this.pieces[i];
			}
			t.upperSet = this.upperSet;
			t.upperTile = this.upperTile;
			return t;
		}

		// ================================================================================================================
	}
}