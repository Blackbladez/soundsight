﻿// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;

namespace UniRPGRuntime
{
	[AddComponentMenu("UniRPG/Ploppable")]
	public class Plop : MonoBehaviour
	{
		[HideInInspector] public Map map = null; // the map/grid that this object is placed on
		[HideInInspector] public UniRPG.PlopKind kind = UniRPG.PlopKind.Prop;

		/// <summary>Preview image of the object. Don't use, it is not inited at runtime and only used by Editor as a cache</summary>
		[System.NonSerialized] public Texture2D _preview = null;
	}
}
