// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	public class UniRPG
	{
		// the map kinds must be 2^x as these values are also used in masks
		public enum MapKind : int { Dungeon = 1, Terrain = 2 } 

		// the kind of tile set, note that the kinds with same name as map must be same int values too
		public enum TileSetKind : int { Single = 0, Dungeon = 1, Terrain = 2, Expanding = 100 }

		// the kind of ploppable, mostly to create some order in inspectors and editor
		public enum PlopKind : int { Player = 0, NPC = 1, Monster = 2, Prop = 3, Pickup = 4, Interact = 5, Trap = 6, Misc1 = 7, Misc2 = 8, Misc3 = 9 }
	}
}