﻿// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PlopInspectorBase : InspectorBase<Plop>
	{

		public enum HeightSnapMode: int { None, Grid, Tiles }
		private static HeightSnapMode heightSnapMode = HeightSnapMode.Grid;
		
		private Vector3 cursorPos = Vector3.zero;

		// ================================================================================================================
		#region Inspector

		public void OnEnable()
		{
			if (Target.map == null)
			{
				// find a default map to sit on
				Object obj = GameObject.FindObjectOfType(typeof(Map));
				if (obj != null) Target.map = (obj as Map);
			}
		}

		public void OnDisable(){}

		public void OnDestroy(){}

		public override void OnInspectorGUI()
		{
			UniRPGEditor.CheckGUISkin();
			EditorGUILayout.Space();
			//this.DrawDefaultInspector();
		}

		#endregion
		// ================================================================================================================
		#region Scene

		public void OnSceneGUI()
		{
			//if (Target.map == null) return;

			//if (heightSnapMode == HeightSnapMode.Tiles)
			//{
			//    Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
			//}

			//else if (heightSnapMode == HeightSnapMode.Grid)
			//{
			//    Vector3 pos = Target.transform.position; pos.y += (Target.map.ed_currentLevel * Target.map.tileHeight);
			//    float dist = 0f;
			//    Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
			//    Plane rayPlane = new Plane(new Vector3(0f, 1f, 0f), pos);
			//    if (rayPlane.Raycast(ray, out dist))
			//    {
			//        pos = ray.GetPoint(dist);
			//        Vector3 p = Target.transform.position;
			//        Target.transform.position = new Vector3(Mathf.Floor((pos.x * Target.map.tileSize)), pos.y + 0.01f, Mathf.Floor((pos.z * Target.map.tileSize)));
			//    }

			//    //cursorPos = new Vector3(Mathf.Floor((pos.x * Target.tileSize) - gridOffset.x), pos.y + 0.01f, Mathf.Floor((pos.z * Target.tileSize) - gridOffset.z));
			//}

		}

		#endregion
		// ================================================================================================================
	}
}
