// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using PLYCommon;

namespace UniRPGEditor
{
	public class UniRPGEditor
	{
		// ================================================================================================================
		#region editor gui resources

		private static Texture2D[] _tileIcons = new Texture2D[27];
		
		public static Texture2D TileIcon_Floor			{ get { if (_tileIcons[0] == null)_tileIcons[0] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_floor.png"); return _tileIcons[0]; } }
		public static Texture2D TileIcon_Wall			{ get { if (_tileIcons[1] == null)_tileIcons[1] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_wall.png"); return _tileIcons[1]; } }
		public static Texture2D TileIcon_Corner1		{ get { if (_tileIcons[2] == null)_tileIcons[2] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_corner_1.png"); return _tileIcons[2]; } }
		public static Texture2D TileIcon_Corner2		{ get { if (_tileIcons[3] == null)_tileIcons[3] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_corner_2.png"); return _tileIcons[3]; } }
		public static Texture2D TileIcon_Corner3		{ get { if (_tileIcons[4] == null)_tileIcons[4] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_corner_3.png"); return _tileIcons[4]; } }
		public static Texture2D TileIcon_Pillar			{ get { if (_tileIcons[5] == null)_tileIcons[5] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.tile_pillar.png"); return _tileIcons[5]; } }

		public static Texture2D TileIcon_TerrainWall	{ get { if (_tileIcons[6] == null)_tileIcons[6] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.terrain_tile_wall.png"); return _tileIcons[6]; } }
		public static Texture2D TileIcon_TerrainCorner1 { get { if (_tileIcons[7] == null)_tileIcons[7] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.terrain_tile_corner_1.png"); return _tileIcons[7]; } }
		public static Texture2D TileIcon_TerrainCorner2 { get { if (_tileIcons[8] == null)_tileIcons[8] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.terrain_tile_corner_2.png"); return _tileIcons[8]; } }

		public static Texture2D Rotate_Icon				{ get { if (_tileIcons[9] == null)_tileIcons[9] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.rotate_ico.png"); return _tileIcons[9]; } }

		public static Texture2D IconToggleOff_Icon		{ get {if (_tileIcons[10] == null) _tileIcons[10] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.IconToggleButtonOff" + (EditorGUIUtility.isProSkin?"":"_l") + ".png"); return _tileIcons[10];}}
		public static Texture2D IconToggleOn_Icon		{ get {if (_tileIcons[11] == null) _tileIcons[11] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.IconToggleButtonOn" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png"); return _tileIcons[11];}}

		public static Texture2D TileIcon_Ex_Single		 { get { if (_tileIcons[12] == null)_tileIcons[12] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_single.png"); return _tileIcons[12]; } }
		public static Texture2D TileIcon_Ex_Full		 { get { if (_tileIcons[13] == null)_tileIcons[13] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_full.png"); return _tileIcons[13]; } }
		public static Texture2D TileIcon_Ex_Sides		 { get { if (_tileIcons[14] == null)_tileIcons[14] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_sides_two.png"); return _tileIcons[14]; } }
		public static Texture2D TileIcon_Ex_One_Side	 { get { if (_tileIcons[15] == null)_tileIcons[15] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_side_one.png"); return _tileIcons[15]; } }
		public static Texture2D TileIcon_Ex_End			 { get { if (_tileIcons[16] == null)_tileIcons[16] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_end.png"); return _tileIcons[16]; } }
		public static Texture2D TileIcon_Ex_Corner1		 { get { if (_tileIcons[17] == null)_tileIcons[17] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_corner1.png"); return _tileIcons[17]; } }
		public static Texture2D TileIcon_Ex_Corner2		 { get { if (_tileIcons[18] == null)_tileIcons[18] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_corner2.png"); return _tileIcons[18]; } }
		public static Texture2D TileIcon_Ex_Junction1	 { get { if (_tileIcons[20] == null)_tileIcons[20] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_junction1.png"); return _tileIcons[20]; } }
		public static Texture2D TileIcon_Ex_Junction2	 { get { if (_tileIcons[22] == null)_tileIcons[22] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_junction2.png"); return _tileIcons[22]; } }
		public static Texture2D TileIcon_Ex_Junction3	 { get { if (_tileIcons[23] == null)_tileIcons[23] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_junction3.png"); return _tileIcons[23]; } }
		public static Texture2D TileIcon_Ex_Crossing1	 { get { if (_tileIcons[24] == null)_tileIcons[24] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_crossing1.png"); return _tileIcons[24]; } }
		public static Texture2D TileIcon_Ex_Crossing2	 { get { if (_tileIcons[19] == null)_tileIcons[19] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_crossing2.png"); return _tileIcons[19]; } }
		public static Texture2D TileIcon_Ex_Crossing3	 { get { if (_tileIcons[25] == null)_tileIcons[25] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_crossing3.png"); return _tileIcons[25]; } }
		public static Texture2D TileIcon_Ex_Crossing4	 { get { if (_tileIcons[26] == null)_tileIcons[26] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_crossing4.png"); return _tileIcons[26]; } }
		public static Texture2D TileIcon_Ex_Crossing5	 { get { if (_tileIcons[21] == null)_tileIcons[21] = PLYEditorUtil.GetTextureResource("UniRPGEditor.Resources.ex_crossing5.png"); return _tileIcons[21]; } }

		#endregion
		// ================================================================================================================
		#region gui styling

		public static float PrefabEdLeftPanelWidth = 200f;

		public static GUIStyle IconToggleButtonOffStyle;
		public static GUIStyle IconToggleButtonOnStyle;

		public static void CheckGUISkin()
		{
			if (IconToggleButtonOnStyle != null) return;

			// load common styles
			PLYEditorUtil.CheckGUISkin();

			// load UniRPG specific styles
			GUISkin inspectorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector);

			IconToggleButtonOnStyle = new GUIStyle();
			IconToggleButtonOffStyle = new GUIStyle();
			IconToggleButtonOnStyle.name = "IconToggleButtonOnStyle";
			IconToggleButtonOffStyle.name = "IconToggleButtonOffStyle";
			IconToggleButtonOnStyle.margin =	IconToggleButtonOffStyle.margin		= new RectOffset(0, 2, 0, 2);
			IconToggleButtonOnStyle.padding =	IconToggleButtonOffStyle.padding	= new RectOffset(3, 3, 3, 3);
			IconToggleButtonOnStyle.border =	IconToggleButtonOffStyle.border		= new RectOffset(3, 3, 3, 3);
			IconToggleButtonOnStyle.normal.background = IconToggleOn_Icon;
			IconToggleButtonOffStyle.normal.background = IconToggleOff_Icon;
		}

		#endregion
		// ================================================================================================================
	}
}