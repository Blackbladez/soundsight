﻿// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PrefabDBPlopsEditor
	{
		private DefPlopSet activeSet = null;
		private int selectedPlop = -1;

		private static Vector2[] scrollPos = { Vector2.zero, Vector2.zero };

		private bool showSetCreate = false;
		private string newset_name = "PlopSet";
		private Color newset_color = Color.cyan;
		private UniRPG.MapKind newset_mapmask = (UniRPG.MapKind.Dungeon | UniRPG.MapKind.Terrain);
		private UniRPG.PlopKind newset_plopkind = UniRPG.PlopKind.Prop;

		public void Render(EditorWindow win)
		{
			EditorGUILayout.BeginHorizontal();
			{
				DrawLeftPanel(win);		// left panel show a list of Sets
				PLYEditorUtil.DrawVerticalLine(2f, PLYEditorUtil.LineColor);
				DrawRightPanel(win);	// the right panel is where the selected set is edited
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawLeftPanel(EditorWindow ed)
		{
			EditorGUILayout.BeginVertical(GUILayout.Width(UniRPGEditor.PrefabEdLeftPanelWidth));
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("+ new set", EditorStyles.miniButton, GUILayout.Width(100)))
				{
					showSetCreate = true; newset_plopkind = UniRPG.PlopKind.Prop;
					newset_name = "PlopSet"; newset_mapmask = (UniRPG.MapKind.Dungeon | UniRPG.MapKind.Terrain);
					newset_color = PLYUtil.RandomColor();
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			scrollPos[0] = EditorGUILayout.BeginScrollView(scrollPos[0]);
			{
				if (PrefabDBEditor.db.plopSets.Count > 0)
				{
					DefPlopSet deleteSet = null;
					foreach (DefPlopSet set in PrefabDBEditor.db.plopSets)
					{
						Rect r = EditorGUILayout.BeginHorizontal();
						{
							r.x += 5; r.width = 50; r.height = 14;
							PLYEditorUtil.DrawFilledRect(r, set.editorColor, true, 5f, -15f, 3f);
							if (PLYEditorUtil.ToggleButton(activeSet == set, set.name, EditorStyles.miniButtonLeft))
							{
								activeSet = set;
								selectedPlop = (activeSet.plops.Count > 0 ? 0 : -1);
							}
							if (GUILayout.Button("X", EditorStyles.miniButtonRight, GUILayout.Width(20)))
							{
								if (EditorUtility.DisplayDialog("Delete the Plop Set?", "Are you sure you want to delete this Plop Set?", "Yes", "No"))
								{
									deleteSet = set;
								}
							}
						}
						EditorGUILayout.EndHorizontal();
					}

					// check if a set was chosen to be deleted
					if (deleteSet != null)
					{
						activeSet = null; selectedPlop = -1;
						PrefabDBEditor.db.plopSets.Remove(deleteSet);
					}

				}
				else
				{
					GUILayout.Label("No sets defined", PLYEditorUtil.WarningLabelStyle);
				}
			}

			GUILayout.Space(20);
			EditorGUILayout.EndScrollView();
			EditorGUILayout.EndVertical();
		}

		private void DrawRightPanel(EditorWindow win)
		{
			if (PrefabDBEditor.db.plopSets.Count == 0)
			{
				activeSet = null; selectedPlop = -1;
				showSetCreate = true;
			}

			if (showSetCreate)
			{
				PLYEditorUtil.BeginBox("Create New Set", GUILayout.MaxWidth(300));
				{
					newset_name = EditorGUILayout.TextField("Set Name:", newset_name);
					newset_color = EditorGUILayout.ColorField("Editor Colour:", newset_color);
					newset_plopkind = (UniRPG.PlopKind)EditorGUILayout.EnumPopup("Kind:", newset_plopkind);
					newset_mapmask = (UniRPG.MapKind)EditorGUILayout.EnumMaskField("Allowed Maps:", newset_mapmask);

					EditorGUILayout.Space();
					EditorGUILayout.BeginHorizontal();
					{
						if (GUILayout.Button("Create"))
						{
							activeSet = new DefPlopSet();
							activeSet.name = newset_name;
							activeSet.editorColor = newset_color;
							activeSet.kind = newset_plopkind;
							activeSet.allowedMapsMask = newset_mapmask;
							PrefabDBEditor.db.plopSets.Add(activeSet);
							showSetCreate = false;
						}
						if (GUILayout.Button("Cancel", GUILayout.Width(100)))
						{
							showSetCreate = false;
						}
					}
					EditorGUILayout.EndHorizontal();
				}
				PLYEditorUtil.EndBox();
				return;
			}

			if (activeSet == null) return;
			scrollPos[1] = EditorGUILayout.BeginScrollView(scrollPos[1]);

			// show set info and options
			EditorGUILayout.BeginHorizontal(GUILayout.ExpandWidth(true));
			{
				PLYEditorUtil.BeginBox("Set Info", GUILayout.MaxWidth(300));
				{
					activeSet.name = EditorGUILayout.TextField("Set Name:", activeSet.name);
					activeSet.editorColor = EditorGUILayout.ColorField("Editor Colour:", activeSet.editorColor);
					activeSet.kind = (UniRPG.PlopKind)EditorGUILayout.EnumPopup("Kind:", activeSet.kind);
					activeSet.allowedMapsMask = (UniRPG.MapKind)EditorGUILayout.EnumMaskField("Allowed Maps:", activeSet.allowedMapsMask);
				}
				PLYEditorUtil.EndBox();

				EditorGUILayout.BeginVertical();
				{
					if (GUILayout.Button("Add New " + activeSet.kind, GUILayout.Width(150)))
					{
						activeSet.plops.Add(null);
					}

					if (selectedPlop == -1) GUI.enabled = false;

					if (GUILayout.Button("Delete "+activeSet.kind, GUILayout.Width(150)))
					{
						if (EditorUtility.DisplayDialog("Delete the " + activeSet.kind + "?", "Are you sure you want to delete this " + activeSet.kind + "?", "Yes", "No"))
						{
							activeSet.plops.RemoveAt(selectedPlop);
							selectedPlop--;
							if (selectedPlop >= activeSet.plops.Count) selectedPlop = activeSet.plops.Count - 1;
						}
					}

					GUI.enabled = true;
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			DrawPlopSetSelectionBar();

			EditorGUILayout.EndScrollView();
		}

		private void DrawPlopSetSelectionBar()
		{
			GUILayout.Space(5);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height;
			r.width = Screen.width - UniRPGEditor.PrefabEdLeftPanelWidth - 24f;

			int columns = Mathf.FloorToInt(r.width / 75f);
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(activeSet.plops.Count / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * 95f) + 4f;

			r = GUILayoutUtility.GetRect(r.width, r.height);

			r.x += 4; r.width -= 20f;
			GUI.Box(r, GUIContent.none);

			r.x += 3; r.y += 3;
			if (activeSet.plops.Count > 0)
			{
				r.width = 64; r.height = 64;
				Rect r2 = r; r2.y = r.yMax + 1; r2.height = 16f;

				int column = 0;
				float startX = r.x;
				bool wasFine = false;

				// show the buttons for selection of plop in this set
				for (int plopIdx = 0; plopIdx < activeSet.plops.Count; plopIdx++)
				{
					if (activeSet.plops[plopIdx] != null)
					{
						Plop p = activeSet.plops[plopIdx].GetComponent<Plop>();
						if (p != null)
						{
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, (selectedPlop == plopIdx), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
							{
								selectedPlop = plopIdx;
							}
						}
						else
						{
							activeSet.plops[plopIdx] = null; // was invalid object type, so reset sommer now
							if (PLYEditorUtil.ActiveButton(r, null, (selectedPlop == plopIdx), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle)) selectedPlop = plopIdx;
						}
					}
					else
					{
						if (PLYEditorUtil.ActiveButton(r, null, (selectedPlop == plopIdx), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle)) selectedPlop = plopIdx;
					}

					activeSet.plops[plopIdx] = (GameObject)EditorGUI.ObjectField(r2, activeSet.plops[plopIdx], typeof(GameObject), false);

					column++; r2.x = r.x += 75f;
					if (column >= columns)
					{
						column = 0; r2.x = r.x = startX;
						r.y += 94;
						r2.y = r.yMax + 1;
					}

					if (selectedPlop == plopIdx) wasFine = true;
				}

				if (!wasFine)
				{	// the active plop is not null, but also not one of the visible plops, not good
					selectedPlop = -1;
				}
			}

			else
			{
				GUI.Label(r, "No "+activeSet.kind+" defined for this set", PLYEditorUtil.WarningLabelStyle);
				selectedPlop = -1; // just to be sure it is null cause some gui rendering checks for it
			}			
		}

		// ================================================================================================================
	}
}
