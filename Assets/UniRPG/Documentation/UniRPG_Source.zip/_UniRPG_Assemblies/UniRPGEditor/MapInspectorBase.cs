// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class MapInspectorBase : InspectorBase<Map>
	{
		// ================================================================================================================
		#region vars

		private static Vector3 PreviewObjectOffset = new Vector3(0f, 0.01f, 0f);

		private static bool inited = false;
		private static bool editModeOn = true;				// will do certain things only when edit mode is active
		private static GameObject UniRPGTempObjects = null;

		// used with single tile and object palcement
		private static TilePiece.Direction currDir = TilePiece.Direction.Up;
		private static GameObject currObj = null; // visual presentation of the object/tile to be placed

		private int ed_selectedSet = -1;								// selected tile set in tile painter tool
		private int ed_selectedTile = -1;								// selected tile in set
		private TilePiece.Kind ed_selectedType = TilePiece.Kind.None;	// selected tile piece in auto-tile
		
		private int ed_selectedPlopSet = -1;
		private int ed_selectedPlop = -1;
		private static bool plopToTileHeight = true;	// else, snap to grid height (only for terrain maps, since dungeon maps only have two heights)
		private static int plopSnapping = 1;			// none, grid, 1/2-grid, 1/3-grid, 1/4-grid, etc
		private static bool plopSnapColliders = false;	// adjust height colliders in same location

		#endregion
		// ================================================================================================================
		#region scene view gui vars

		public static Color Cursor3D_Color = new Color(0f, 0.5f, 1f, 1f);
		public static Color Cursor3D_PlaceCol = new Color(1f, 1f, 1f, 0.5f);
		public static Color Cursor3D_DelCol = new Color(0.3f, 0f, 0f, 0.5f);
		public static Color ActiveDirButton_Col = new Color(0f, 0.6f, 1f);

		private static Vector3 gridOffset = Vector3.zero;	// offset when calcualting snap position
		private bool dragOnGrid = false;					// helper to track when drawing tiles/mouse-held
		private bool onTheGrid = false;						// true while mouse over the grid
		private Vector3 cursorPos = Vector3.zero;			// position of mouse/cursor on the grid

		#endregion
		// ================================================================================================================
		#region inspector gui vars

		private static string[] ToolLabels = { "Tiles", "Auto-Tiles", "Plops" };
		private enum ToolTypes : int { Tiles=0, AutoTiles=1, Plops=2 }
		private static ToolTypes selectedTool = ToolTypes.Tiles;

		private static bool forceTargetDirty = false;		// force a redraw of Target
		private static bool forceGuiDirty = false;			// force a redraw of Inspector
		private static bool[] folds = { true };				// helper for various fold & toggles

		private int brushSize = 1;							// size of brush that paints auto-tiles
		private int currentPlacementHeight = 0;				// helper which adapts when in moldingMode and might differ from Target.ed_currentLevel
		private bool autoTilesSelection = false;			// helper with Normal Tiles Tool where both Normal and Auto-Tiles are shown
		private static bool moldingMode = false;			// in this mode left click will draw raised tile and right click will draw lowered tile
		private static bool tileReplaceMode = false;		// in this mode an existing tile will be replaced when placing tiles via Normal Tile pacement tool
		private static bool floorRandomRot = true;			// random rotation of auto-tile floor?
		private static bool floorRandomTile = false;		// random floor tile from set?

		#endregion
		// ================================================================================================================
		#region enable/disable

		public void OnEnable()
		{
			dragOnGrid = false;
			onTheGrid = false;

			if (!inited)
			{
				inited = true;

				// check if there is any junk left in the temp container
				// just wipe the whole container, it will be recreated later
				GameObject temp = GameObject.Find("UniRPGTempObjects");
				if (temp != null) DestroyImmediate(temp);

				// hide the wireframes on existing floor and wall pieces
				for (int i = 0; i < Target.transform.childCount; i++)
				{
					PLYEditorUtil.HideRendererWireframe(Target.transform.GetChild(i).gameObject);
				}

				PreviewObjectOffset = new Vector3(0f, Target.tileHeight / 50f, 0f);

				gridOffset = Target.transform.position;
				gridOffset.x -= Target.tileSize / 2f;
				gridOffset.z -= Target.tileSize / 2f;
			}

			// check if must respawn the preview object
			CheckCurrObj();
		}

		public void OnDisable()
		{
			inited = false;
			dragOnGrid = false;
			onTheGrid = false;

			currObj = null;
			GameObject temp = GameObject.Find("UniRPGTempObjects");
			if (temp != null) DestroyImmediate(temp);
		}

		public void OnDestroy()
		{
			currObj = null;
			GameObject temp = GameObject.Find("UniRPGTempObjects");
			if (temp != null) DestroyImmediate(temp);
		}

		#endregion
		// ================================================================================================================
		#region Misc

		private void ChangeDirection(bool toRight, bool allowAngled, bool forceUpdate)
		{
			if (toRight)
			{
					 if (currDir == TilePiece.Direction.Up) currDir = (allowAngled ? TilePiece.Direction.UpR : TilePiece.Direction.Right);
				else if (currDir == TilePiece.Direction.Right) currDir = (allowAngled ? TilePiece.Direction.DwnR : TilePiece.Direction.Down);
				else if (currDir == TilePiece.Direction.Down) currDir = (allowAngled ? TilePiece.Direction.DwnL : TilePiece.Direction.Left);
				else if (currDir == TilePiece.Direction.Left) currDir = (allowAngled ? TilePiece.Direction.UpL : TilePiece.Direction.Up);
				else if (currDir == TilePiece.Direction.UpR) currDir = TilePiece.Direction.Right;
				else if (currDir == TilePiece.Direction.DwnR) currDir = TilePiece.Direction.Down;
				else if (currDir == TilePiece.Direction.DwnL) currDir = TilePiece.Direction.Left;
				else if (currDir == TilePiece.Direction.UpL) currDir = TilePiece.Direction.Up;
			}
			else
			{
					 if (currDir == TilePiece.Direction.Up) currDir = (allowAngled ? TilePiece.Direction.UpL : TilePiece.Direction.Left);
				else if (currDir == TilePiece.Direction.Right) currDir = (allowAngled ? TilePiece.Direction.UpR : TilePiece.Direction.Up);
				else if (currDir == TilePiece.Direction.Down) currDir = (allowAngled ? TilePiece.Direction.DwnR : TilePiece.Direction.Right);
				else if (currDir == TilePiece.Direction.Left) currDir = (allowAngled ? TilePiece.Direction.DwnL : TilePiece.Direction.Down);
				else if (currDir == TilePiece.Direction.UpR) currDir = TilePiece.Direction.Up;
				else if (currDir == TilePiece.Direction.DwnR) currDir = TilePiece.Direction.Right;
				else if (currDir == TilePiece.Direction.DwnL) currDir = TilePiece.Direction.Down;
				else if (currDir == TilePiece.Direction.UpL) currDir = TilePiece.Direction.Left;
			}

			if (forceUpdate && currObj != null)
			{
				Vector3 rot = currObj.transform.localRotation.eulerAngles;
				rot.y = (float)currDir;
				currObj.transform.localRotation = Quaternion.Euler(rot);
			}
		}

		private void CheckCurrObj()
		{
			if (currObj == null && editModeOn && selectedTool == ToolTypes.Tiles)
			{
				if ( ed_selectedType != TilePiece.Kind.None && ed_selectedTile >= 0 && ed_selectedSet >= 0 && ed_selectedSet < Target.db.autoTiles.Count)
				{
					if (ed_selectedTile < Target.db.autoTiles[ed_selectedSet].tiles.Count)
					{
						DefAutoTile t = Target.db.autoTiles[ed_selectedSet].tiles[ed_selectedTile];
						if (t.pieces[(int)ed_selectedType] != null) SpawnCurrObj(t.pieces[(int)ed_selectedType].gameObject);
					}
				}
			}
		}

		private void SpawnCurrObj(GameObject fab)
		{
			// first check if there is container for these temp objects
			if (UniRPGTempObjects == null)
			{
				UniRPGTempObjects = GameObject.Find("UniRPGTempObjects");
				if (UniRPGTempObjects == null)
				{	// still null, create one now
					UniRPGTempObjects = new GameObject();
					UniRPGTempObjects.name = "UniRPGTempObjects";
				}
			}

			// just to be sure it is stil lcentered in case user moved it around
			UniRPGTempObjects.transform.position = Vector3.zero;

			// spawn a presentation of the selected tile/object/etc
			if (currObj != null) DestroyImmediate(currObj);
			currObj = Instantiate(fab) as GameObject;
			currObj.name = "Object_Preview";
			currObj.transform.parent = UniRPGTempObjects.transform;
			currObj.transform.position = cursorPos + PreviewObjectOffset;
			Vector3 rot = currObj.transform.localRotation.eulerAngles;
			rot.y = (float)currDir;
			currObj.transform.localRotation = Quaternion.Euler(rot);

			// turn off collider(s) for preview object
			PLYUtil.DestroyColliders(currObj);
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI

		public override void OnInspectorGUI()
		{
			UniRPGEditor.CheckGUISkin();
			EditorGUILayout.Space();

			// meta info
			folds[0] = PLYEditorUtil.BeginVerticalFold("Map Info", folds[0]);
			if (folds[0])
			{
				GUILayout.Label(string.Format("( {0} Map ) ( {1}x{2} => {3} tiles )", Target.kind.ToString(), Target.width, Target.length, (Target.width * Target.length)));
				Target.gizmoGrid = EditorGUILayout.Toggle("Show grid", Target.gizmoGrid);
				editModeOn = PLYEditorUtil.Toggle(editModeOn, "Toggle Edit Mode", null, GUILayout.MaxWidth(150));
			}
			PLYEditorUtil.EndVerticalFold();
			EditorGUILayout.Space();

			// ****************************************************
			// edit mode inspector

			if (editModeOn)
			{
				ToolTypes prev = selectedTool;
				selectedTool = (ToolTypes)GUILayout.Toolbar((int)selectedTool, ToolLabels);

				if (prev != selectedTool && (selectedTool == ToolTypes.Plops || prev == ToolTypes.Plops))
				{	// reset the plops when entering its tool from another
					ed_selectedPlopSet = -1;
					ed_selectedPlop = -1;
					if (currObj != null) DestroyImmediate(currObj);
				}

				GUILayout.BeginVertical(PLYEditorUtil.BoxStyle);
				{
					GUILayout.Label("Options", EditorStyles.boldLabel);
					EditorGUILayout.BeginHorizontal();
					{
						if (selectedTool == ToolTypes.Plops)
						{
							GUI.enabled = false;
							EditorGUILayout.IntField("Brush Size:", 1, GUILayout.MaxWidth(200));
						}
						else
						{
							brushSize = EditorGUILayout.IntField("Brush Size:", brushSize, GUILayout.MaxWidth(200));
						}
						if (GUILayout.Button("-", EditorStyles.miniButtonLeft, GUILayout.Width(25))) { brushSize--; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						if (GUILayout.Button("+", EditorStyles.miniButtonMid, GUILayout.Width(25))) { brushSize++; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						GUILayout.Space(2);
						if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.Width(25))) { brushSize = 1; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true;
					}
					EditorGUILayout.EndHorizontal();

					// tile options (different height tiles are only supported on terrain maps, not dungeon and world maps)
					if (Target.kind == UniRPG.MapKind.Terrain)
					{
						EditorGUILayout.BeginHorizontal();
						{
							Target.ed_currentLevel = EditorGUILayout.IntField("Draw Height Level:", Target.ed_currentLevel, GUILayout.MaxWidth(200));
							if (GUILayout.Button("-", EditorStyles.miniButtonLeft, GUILayout.Width(25))) { Target.ed_currentLevel--; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
							if (GUILayout.Button("+", EditorStyles.miniButtonMid, GUILayout.Width(25))) { Target.ed_currentLevel++; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
							GUILayout.Space(2);
							if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.MaxWidth(25))) { Target.ed_currentLevel = 0; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();

						if (selectedTool == ToolTypes.AutoTiles)
						{
							moldingMode = EditorGUILayout.Toggle("Raise/Lower Mode:", moldingMode);
						}
					}

					if (selectedTool == ToolTypes.Tiles)
					{
						tileReplaceMode = EditorGUILayout.Toggle("Replace Existing:", tileReplaceMode);
					}
					else if (selectedTool == ToolTypes.AutoTiles)
					{
						if (ed_selectedSet >= 0 && ed_selectedSet < Target.db.autoTiles.Count)
						{
							if (Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Expanding)
							{
								tileReplaceMode = EditorGUILayout.Toggle("Replace Existing:", tileReplaceMode);
							}
							else
							{
								GUI.enabled = false;
								EditorGUILayout.Toggle("Replace Existing:", true);
								GUI.enabled = true;
							}

							if (Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Dungeon || Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Terrain)
							{
								floorRandomRot = EditorGUILayout.Toggle("Floor Random Rotation:", floorRandomRot);
								floorRandomTile = EditorGUILayout.Toggle("Floor Random Tile:", floorRandomTile);
							}
							else
							{
								GUI.enabled = false;
								EditorGUILayout.Toggle("Floor Random Rotation:", false);
								EditorGUILayout.Toggle("Floor Random Tile:", false);
								GUI.enabled = true;
							}
						}
						else
						{
							GUI.enabled = false;
							EditorGUILayout.Toggle("Replace Existing:", true);
							EditorGUILayout.Toggle("Floor Random Rotation:", false);
							GUI.enabled = true;
						}

					}

					if (selectedTool != ToolTypes.AutoTiles) 
					{ 
						EditorGUILayout.Space();
						DrawDirectionButtons(selectedTool == ToolTypes.Plops);
					}

					if (selectedTool == ToolTypes.Plops)
					{
						GUILayout.Label("Snapping:", EditorStyles.boldLabel);
						EditorGUILayout.BeginHorizontal();
						{
							if (PLYEditorUtil.ToggleButton((plopSnapping == 0), "None", EditorStyles.miniButtonLeft, GUILayout.Width(60))) { plopSnapping = 0; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 1), "Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 1; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 2), "1/2-Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 2; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 3), "1/3-Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 3; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 4), "1/4-Tile", EditorStyles.miniButtonRight, GUILayout.Width(60))) { plopSnapping = 4; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.Space();
						EditorGUILayout.BeginHorizontal();
						{
							EditorGUILayout.PrefixLabel("Snap Height:");
							if (PLYEditorUtil.ToggleButton(plopToTileHeight, "Tiles", EditorStyles.miniButtonLeft, GUILayout.Width(60))) { plopToTileHeight = true; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton(!plopToTileHeight, "Grid", EditorStyles.miniButtonRight, GUILayout.Width(60))) { plopToTileHeight = false; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();
						plopSnapColliders = EditorGUILayout.Toggle("Snap height to colliders:", plopSnapColliders);
					}

					// draw the sets
					switch (selectedTool)
					{
						case ToolTypes.Tiles: DrawTileSetsAndTileTypeOfKind(Target.kind); break;
						case ToolTypes.AutoTiles: DrawAutoTileSetsOfKind(Target.kind); break;
						case ToolTypes.Plops: DrawPlopSelection(Target.kind);  break;
					}

					// some buttons
					PLYEditorUtil.DrawHorizontalLine(1f, PLYEditorUtil.LineColor, 10f, 5f);
					//GUILayout.Label("Warning: The following removes existing tiles", EditorStyles.miniLabel);
					EditorGUILayout.BeginHorizontal();
					{
						if (selectedTool == ToolTypes.Tiles || selectedTool == ToolTypes.AutoTiles)
						{
							if (ed_selectedSet == -1 || ed_selectedTile == -1) GUI.enabled = false;
							if (GUILayout.Button("Flood Fill", GUILayout.MaxWidth(100)))
							{	// spawn floor tiles and hide the wireframes of each
								if (selectedTool == ToolTypes.AutoTiles)
								{
									ed_selectedType = TilePiece.Kind.Floor;
									Target.FloodFillAutoTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, ed_selectedType);
								}
								else if (selectedTool == ToolTypes.Tiles)
								{
									if (autoTilesSelection) Target.FloodFillAutoTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, ed_selectedType, currDir);
									else Target.FloodFillTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, currDir);
								}

								for (int i = 0; i < Target.transform.childCount; i++) PLYEditorUtil.HideRendererWireframe(Target.transform.GetChild(i).gameObject);
							}

							GUI.enabled = true;
							if (GUILayout.Button("Remove All Tiles", GUILayout.MaxWidth(120))) Target.RemoveAllTiles();
						}

						//if (selectedTool == ToolTypes.Plops)
						//{
						//    if (GUILayout.Button("Remove All Plops", GUILayout.MaxWidth(120))) Target.RemoveAllPlops();
						//}

						if (GUILayout.Button("Edit PrefabDB", GUILayout.MaxWidth(120)))
						{
							Selection.activeGameObject = Target.db.gameObject;
							PrefabDBEditor.ShowEditor();
						}

					}
					EditorGUILayout.EndHorizontal();

				}
				EditorGUILayout.Space();
				GUILayout.EndVertical();
			}

			// ****************************************************

			if (GUI.changed || forceTargetDirty)
			{
				if (brushSize < 1) brushSize = 1; // dungeon supports only size-1 brushes
				else if (brushSize > 5) brushSize = 5;
				
				forceTargetDirty = false;
				EditorUtility.SetDirty(Target);
			}
		}

		private void DrawDirectionButtons(bool allowAngled)
		{
			if (currDir == TilePiece.Direction.Invalid || (!allowAngled && currDir != TilePiece.Direction.Up && currDir != TilePiece.Direction.Down && currDir != TilePiece.Direction.Right && currDir != TilePiece.Direction.Left))
			{
				currDir = TilePiece.Direction.Up;
			}

			TilePiece.Direction prevDir = currDir;
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.PrefixLabel("Direction:");

				EditorGUILayout.BeginVertical();
				{
					if (GUILayout.Button(UniRPGEditor.Rotate_Icon, GUILayout.Width(35))) { ChangeDirection(true, allowAngled, false); PLYEditorUtil.FocusSceneView(); }
					GUILayout.Label(currDir.ToString(), EditorStyles.miniLabel);
				}
				EditorGUILayout.EndVertical();
				GUILayout.Space(10);

				EditorGUILayout.BeginVertical(GUILayout.Width(60));
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.UpL ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.UpL), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.UpL; PLYEditorUtil.FocusSceneView(); }

						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Up ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Up), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Up; PLYEditorUtil.FocusSceneView(); }

						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.UpR ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.UpR), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.UpR; PLYEditorUtil.FocusSceneView(); }
					}
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Left ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Left), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Left; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = false; GUI.backgroundColor = Color.white;
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Invalid), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Invalid; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Right ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Right), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Right; PLYEditorUtil.FocusSceneView(); }
					}
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.DwnL ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.DwnL), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.DwnL; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Down ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Down), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Down; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.DwnR ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.DwnR), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.DwnR; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.enabled = true; GUI.backgroundColor = Color.white;
					}
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.EndVertical();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();	

			// update object rotation
			if (currObj != null && currDir != prevDir)
			{
				Vector3 rot = currObj.transform.localRotation.eulerAngles;
				rot.y = (float)currDir;
				currObj.transform.localRotation = Quaternion.Euler(rot);
			}
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI - Tool 2: Plops

		private void DrawPlopSelection(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;
			bool setWasPresent = false; // helper to check if the set selected set can be used (so can auto deselect it if needed)
			bool isFirst = true;

			if (Target.db.plopSets.Count > 0)
			{
				for (int setIdx = 0; setIdx < Target.db.plopSets.Count; setIdx++ )
				{
					if ((Target.db.plopSets[setIdx].allowedMapsMask & mapKind) == mapKind)
					{
						DrawPlopSetSelectionBar(Target.db.plopSets[setIdx], setIdx, (isFirst?1:0));
						if (ed_selectedPlopSet == setIdx) setWasPresent = true;
						isFirst = false;
						drawNothing = false;
					}
				}
			}

			if (!setWasPresent)
			{
				ed_selectedPlopSet = -1;
				ed_selectedPlop = -1;
			}

			if (drawNothing) GUILayout.Label("No sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawPlopSetSelectionBar(DefPlopSet set, int setIdx, int blankPlop)
		{
			GUILayout.Label(set.name, EditorStyles.boldLabel);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the thumbs
			float spaceWidth = Screen.width - 25;

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditor.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt((set.plops.Count + blankPlop) / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			bool showErr = true;
			float startX = r.x;
			float startY = r.y;

			if (set.plops.Count > 0)
			{
			    r.width = 64; r.height = 64;
			    int column = 0;

				if (blankPlop == 1)
				{
					if (PLYEditorUtil.ActiveButton(r, null, "clear", (ed_selectedPlopSet == -1 && ed_selectedPlop == -1), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
					{
						ed_selectedPlopSet = -1;
						ed_selectedPlop = -1;
						if (currObj != null) DestroyImmediate(currObj);
						PLYEditorUtil.FocusSceneView();
					}

					column++; r.x += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.right;
					if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom; }
				}

				// show the buttons for selection of plops in this set
				for (int j = 0; j < set.plops.Count; j++)
				{
					if (set.plops[j] != null)
					{
						Plop p = set.plops[j].GetComponent<Plop>();
						if (p != null)
						{
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (ed_selectedPlopSet == setIdx && ed_selectedPlop == j), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
							{
								ed_selectedPlopSet = setIdx;
								ed_selectedPlop = j;
								SpawnCurrObj(p.gameObject);
								PLYEditorUtil.FocusSceneView();
							}

							showErr = false;
							column++; r.x += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.right;
							if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom; }
						}
					}
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid plops defined for this set", PLYEditorUtil.WarningLabelStyle);
			}
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI - Tool 0: Tiles and Tool 1: AutoTile

		private void DrawAutoTileSetsOfKind(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;

			if (Target.db.autoTiles.Count > 0)
			{
				for (int i = 0; i < Target.db.autoTiles.Count; i++)
				{
					if ((Target.db.autoTiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						if (ed_selectedSet == -1) ed_selectedSet = i;

						drawNothing = false;
						DrawAutoTileSetSelectionBar(Target.db.autoTiles[i], i);
					}
				}
			}

			if (drawNothing) GUILayout.Label("No tile sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawTileSetsAndTileTypeOfKind(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;

			if (Target.db.tiles.Count > 0)
			{
				for (int i = 0; i < Target.db.tiles.Count; i++)
				{
					if ((Target.db.tiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						if (ed_selectedSet == -1)
						{
							autoTilesSelection = false;
							ed_selectedSet = i;
						}
						drawNothing = false;
						DrawTilesSelectionBar(Target.db.tiles[i], i);
					}
				}
			}

			if (Target.db.autoTiles.Count > 0)
			{				
				for (int i = 0; i < Target.db.autoTiles.Count; i++)
				{
					if ((Target.db.autoTiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						if (ed_selectedSet == -1)
						{
							autoTilesSelection = true;
							ed_selectedSet = i;
						}
						drawNothing = false;
						DrawAutoTileSetAndPiecesSelectionBar(Target.db.autoTiles[i], i);
					}
				}
			}

			if (drawNothing) GUILayout.Label("No tile sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawAutoTileSetSelectionBar(DefAutoTileSet set, int setId)
		{
			GUILayout.Label(set.name, EditorStyles.boldLabel);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the tile thumbs. 15 = space taken by padding and colour bit
			//float spaceWidth = Screen.width - (r.x * 2) - 15;
			float spaceWidth = Screen.width - 25;

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditor.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(set.tiles.Count / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			bool showErr = true;
			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
				{
					if (set.tiles[j].pieces[(int)TilePiece.Kind.Floor] != null)
					{
						TilePiece p = set.tiles[j].pieces[(int)TilePiece.Kind.Floor].GetComponent<TilePiece>();
						if (p != null)
						{
							// if no tile is yet selected, select a default one now
							if (ed_selectedTile == -1) ed_selectedTile = j;

							// show tile
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, (ed_selectedSet == setId && ed_selectedTile == j), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
							{
								ed_selectedSet = setId;
								ed_selectedTile = j;
							}

							showErr = false;
							column++; r.x += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.right;
							if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom; }
						}

					}
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private void DrawAutoTileSetAndPiecesSelectionBar(DefAutoTileSet set, int setId)
		{
			GUILayout.Label(set.name, EditorStyles.boldLabel);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the tile thumbs. 15 = space taken by padding and colour bit
			//float spaceWidth = Screen.width - (r.x * 2) - 15;
			float spaceWidth = Screen.width - 25;

			bool showErr = true;
			int piecesCount = set.tiles.Count;
			for (int j = 0; j < set.tiles.Count; j++)
				for (int pieceIdx = 0; pieceIdx < set.tiles[j].pieces.Length; pieceIdx++)
				{
					if (set.tiles[j].pieces[pieceIdx] != null)
					{
						showErr = false; if (pieceIdx != 0) piecesCount++; // dont count floor (idx = 0)
					}
				}

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditor.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(piecesCount / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
					for (int pieceIdx = 0; pieceIdx < set.tiles[j].pieces.Length; pieceIdx++)
					{
						r = DrawTilePieceButton(r, set.tiles[j].pieces[pieceIdx], true, setId, j, (TilePiece.Kind)pieceIdx, ref column, columns, startX);
					}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private void DrawTilesSelectionBar(DefTileSet set, int setId)
		{
			GUILayout.Label(set.name, EditorStyles.boldLabel);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label
			float spaceWidth = Screen.width - 25;
			bool showErr = true;
			int piecesCount = set.tiles.Count;
			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditor.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(piecesCount / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
				{
					showErr = false;
					r = DrawTilePieceButton(r, set.tiles[j], false, setId, j, TilePiece.Kind.None, ref column, columns, startX);
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private Rect DrawTilePieceButton(Rect r, GameObject piece, bool isAutoTile, int setId, int tileId, TilePiece.Kind tileType, ref int column, int columns, float startX)
		{
			if (piece != null)
			{
				TilePiece p = piece.GetComponent<TilePiece>();
				if (p != null)
				{
					// if no tile is yet selected, select a default one now
					if (ed_selectedTile == -1)
					{
						ed_selectedTile = tileId;
						ed_selectedType = tileType;
					}

					// show floor piece
					if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
					if (isAutoTile)
					{
						if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (autoTilesSelection && ed_selectedSet == setId && ed_selectedTile == tileId && ed_selectedType == tileType), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
						{
							autoTilesSelection = true;
							ed_selectedSet = setId;
							ed_selectedTile = tileId;
							ed_selectedType = tileType;
							SpawnCurrObj(p.gameObject);
							PLYEditorUtil.FocusSceneView();
						}
					}
					else
					{
						if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (!autoTilesSelection && ed_selectedSet == setId && ed_selectedTile == tileId), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle))
						{
							autoTilesSelection = false;
							ed_selectedSet = setId;
							ed_selectedTile = tileId;
							ed_selectedType = TilePiece.Kind.None;
							SpawnCurrObj(p.gameObject);
							PLYEditorUtil.FocusSceneView();
						}
					}

					column++; r.x += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.right;
					if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom; }
				}
			}
			return r;
		}

		#endregion
		// ================================================================================================================
		#region Scene GUI

		public void OnSceneGUI()
		{
			if (editModeOn)
			{
				// force the "view" mode
				Tools.current = Tool.View;
				//if (Event.current.type == EventType.Layout)
				//{
				//    HandleUtility.AddDefaultControl(GUIUtility.GetControlID(FocusType.Passive));
				//}
			}
			if (editModeOn && EditorWindow.mouseOverWindow!=null)
			{
				//// auto focus sceneview when mouse over
				//if (EditorWindow.mouseOverWindow is SceneView)
				//{
				//    EditorWindow.mouseOverWindow.Focus();
				//}

				// draw scene view related gui and handles
				OnSceneGUI_Editor();
				OnSceneGUI_Info();
			}

			if (forceGuiDirty)
			{	// repaint the Inspector now
				forceGuiDirty = false;
				this.Repaint();
			}
		}

		private void OnSceneGUI_Info()
		{
			if (Event.current.type == EventType.KeyUp)
			{
				if (Event.current.control)
				{
					if (Target.kind == UniRPG.MapKind.Terrain)
					{	// change height
						if (Event.current.keyCode == KeyCode.UpArrow) { Target.ed_currentLevel++; forceGuiDirty = true; Event.current.Use(); }
						if (Event.current.keyCode == KeyCode.DownArrow) { Target.ed_currentLevel--; forceGuiDirty = true; Event.current.Use(); }
					}

					if (selectedTool != ToolTypes.AutoTiles)
					{	// rotate active tile/plop
						if (Event.current.keyCode == KeyCode.LeftArrow) { ChangeDirection(false, (selectedTool==ToolTypes.Plops), true); forceGuiDirty = true; Event.current.Use(); }
						if (Event.current.keyCode == KeyCode.RightArrow) { ChangeDirection(true, (selectedTool == ToolTypes.Plops), true); forceGuiDirty = true; Event.current.Use(); }
					}
				}

				if (Target.kind == UniRPG.MapKind.Terrain && selectedTool == ToolTypes.AutoTiles)
				{	// toggle molding mode
					if (Event.current.keyCode == KeyCode.Tab) { moldingMode = !moldingMode; forceGuiDirty = true; Event.current.Use(); }
				}

				if (selectedTool == ToolTypes.Tiles)
				{	// toggle replace mode
					if (Event.current.keyCode == KeyCode.Tab) { tileReplaceMode = !tileReplaceMode; forceGuiDirty = true; Event.current.Use(); }
				}

				if (editModeOn)
				{
					if (Event.current.keyCode == KeyCode.Delete && selectedTool == ToolTypes.Plops)
					{	// delete the selected plop
						forceGuiDirty = true; Event.current.Use();
						if (currObj != null) DestroyImmediate(currObj);
						ed_selectedPlop = -1; ed_selectedPlopSet = -1;
					}

					if (Event.current.keyCode == KeyCode.Escape)
					{
						editModeOn = false; forceGuiDirty = true; Event.current.Use();
						if (currObj != null) DestroyImmediate(currObj);
					}
				}

			}

			//Handles.BeginGUI(); GUILayout.BeginArea(new Rect(0,0,200,300), PLYEditorUtil.BoxStyle);
			//{
			//    GUILayout.Label("Will put some info here");
			//}
			//GUILayout.EndArea(); Handles.EndGUI();
		}

		private void OnSceneGUI_Editor()
		{
			// find mouse position on grid
			Vector3 pos = Target.transform.position; pos.y += (Target.ed_currentLevel * Target.tileHeight);
			float dist = 0f;
			Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
			Plane rayPlane = new Plane(new Vector3(0f, 1f, 0f), pos);
			if (rayPlane.Raycast(ray, out dist))
			{
				pos = ray.GetPoint(dist);

				// only bother to continue if the mouse is over the grid
				if (pos.x - gridOffset.x >= 0 && pos.z - gridOffset.z >= 0 && pos.x - gridOffset.x < Target.width * Target.tileSize && pos.z - gridOffset.z < Target.length * Target.tileSize)
				{
					onTheGrid = true;
					Color currcol = (Event.current.button == 1 ? Cursor3D_DelCol : Cursor3D_PlaceCol);

					if (Event.current.button != 1)
					{
						if (autoTilesSelection || selectedTool == ToolTypes.AutoTiles)
						{
							if (ed_selectedSet < Target.db.autoTiles.Count && ed_selectedSet >= 0 && ed_selectedTile >= 0)
							{
								if (Target.db.autoTiles[ed_selectedSet] != null)
								{
									currcol = Target.db.autoTiles[ed_selectedSet].editorColor;
									currcol.a = (currObj != null ? 0.1f : 0.5f);
								}
							}
						}
						else
						{
							if (ed_selectedSet < Target.db.tiles.Count && ed_selectedSet >= 0 && ed_selectedTile >= 0)
							{
								if (Target.db.tiles[ed_selectedSet] != null)
								{
									currcol = Target.db.tiles[ed_selectedSet].editorColor;
									currcol.a = (currObj != null ? 0.1f : 0.5f);
								}
							}
						}
					}

					// calc pos for plops
					if (selectedTool == ToolTypes.Plops)
					{
						if (plopToTileHeight)
						{
							// find out which tile the plop is over
							cursorPos = new Vector3(Mathf.Floor((pos.x * Target.tileSize) - gridOffset.x), pos.y, Mathf.Floor((pos.z * Target.tileSize) - gridOffset.z));
							int y = (int)(cursorPos.z / Target.tileSize);
							int x = (int)(cursorPos.x / Target.tileSize);
							int idx = y * Target.width + x;
							if (idx >= 0 && idx < Target.tiles.Length)
							{
								if (Target.tiles[idx] != null)
								{
									pos.y = Target.tiles[idx].transform.position.y;
								}
							}
						}

						if (plopSnapping == 0)
						{
							cursorPos = new Vector3(pos.x, pos.y, pos.z);
						}
						else
						{
							float s = Target.tileSize / (float)plopSnapping;
							pos.x -= gridOffset.x / (float)plopSnapping;
							pos.z -= gridOffset.z / (float)plopSnapping;
							cursorPos = new Vector3
							(
								s * (int)(pos.x / (float)s),
								pos.y,
								s * (int)(pos.z / (float)s)
							);
						}

						if (plopSnapColliders)
						{	// adjust height of plop so it does not stick through plop below it

							Vector3 start = cursorPos; start.y += (Target.tileHeight * 20f);
							RaycastHit[] hits = Physics.RaycastAll(start, -Vector3.up, (Target.tileHeight * 20f));
							if (hits.Length > 0)
							{
								for (int i=0; i<hits.Length; i++)
								{									
									if (null != hits[i].collider.gameObject.GetComponent<TilePiece>()) continue;
									if (cursorPos.y < hits[i].point.y) cursorPos.y = hits[i].point.y;
								}
							}
						}
					}

					// calc pos for tiles
					else
					{
						pos.x -= gridOffset.x;
						pos.z -= gridOffset.z;
						cursorPos = new Vector3
						(
							Target.tileSize * (int)(pos.x / (float)Target.tileSize),
							pos.y,
							Target.tileSize * (int)(pos.z / (float)Target.tileSize)
						);

						if (!Event.current.alt)
						{
							if (brushSize > 1) PLYEditorUtil.SceneDrawRects(brushSize, cursorPos, Target.tileSize, Target.tileSize, currcol, Cursor3D_Color);
							else PLYEditorUtil.SceneDrawRect(cursorPos, Target.tileSize, Target.tileSize, currcol, Cursor3D_Color);
							HandleUtility.Repaint();
						}
					}

					if (currObj != null)
					{
						if (selectedTool == ToolTypes.AutoTiles)
						{	// dont show the object in auto-tile mode
							DestroyImmediate(currObj);
						}
						else
						{
							if (!currObj.active)
							{
								if (Event.current.button != 1 && !Event.current.alt) currObj.SetActiveRecursively(true);
							}
							else
							{	// hide the object if right-mouse held, which is for deleting tiles
								if (Event.current.button == 1 || Event.current.alt) currObj.SetActiveRecursively(false);
							}
							currObj.transform.position = cursorPos + PreviewObjectOffset;
							if (Target.kind == UniRPG.MapKind.Dungeon && selectedTool == ToolTypes.Tiles)
							{
								if (Target.db.autoTiles[ed_selectedSet].isLower) currObj.transform.position -= new Vector3(0f, Target.tileHeight, 0f);
							}
						}
					}
					else if (selectedTool == ToolTypes.Tiles && !Event.current.alt)
					{	// only auto-spawm preview object for tiles tool
						CheckCurrObj();
					}
					
				}
				else
				{
					onTheGrid = false;
					if (currObj != null) currObj.SetActiveRecursively(false);
				}
			}

			// handle input
			if (Event.current.type == EventType.mouseDown && (Event.current.button == 0 || Event.current.button == 1))
			{
				if (onTheGrid && !Event.current.alt && !Event.current.control && (Event.current.button == 0 || Event.current.button == 1))
				{
					dragOnGrid = true;
					int y = (int)(cursorPos.z / Target.tileSize);
					int x = (int)(cursorPos.x / Target.tileSize);

					switch (selectedTool)
					{
						case ToolTypes.AutoTiles:
						{
							currentPlacementHeight = Target.ed_currentLevel;
							if (moldingMode && Target.kind == UniRPG.MapKind.Terrain)
							{	// check if clicked on existing tile and adapt to its height
								int idx = y * Target.width + x;

								if (Target.tiles[idx] != null)
								{
									TilePiece piece = Target.tiles[idx].GetComponent<TilePiece>();
									//if (piece.type == TilePiece.Type.Floor)
									//{
										if (Event.current.button == 0)
										{
											if (piece.floorLevel < Target.ed_currentLevel) currentPlacementHeight = piece.floorLevel + 1;
											else currentPlacementHeight = Target.ed_currentLevel + 1;
										}
										else if (Event.current.button == 1)
										{
											if (piece.floorLevel > Target.ed_currentLevel) currentPlacementHeight = piece.floorLevel - 1;
											else currentPlacementHeight = Target.ed_currentLevel - 1;
										}
									//}
								}
							}
							if (Target.kind == UniRPG.MapKind.Dungeon) PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0));
							else PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0 || moldingMode));
						} break;

						case ToolTypes.Tiles:
						{
							PlaceTile(x, y, Event.current.button == 0);
						} break;

						case ToolTypes.Plops:
						{
							PlacePlop();
						} break;
					}

				}
			}

			if (Event.current.type == EventType.dragPerform || Event.current.type == EventType.DragExited ||
				Event.current.type == EventType.dragUpdated || Event.current.type == EventType.mouseDrag)
			{
				if (dragOnGrid && !Event.current.alt && !Event.current.control && (Event.current.button == 0 || Event.current.button == 1))
				{
					switch (selectedTool)
					{
						case ToolTypes.AutoTiles:
						{
							int y = (int)(cursorPos.z / Target.tileSize);
							int x = (int)(cursorPos.x / Target.tileSize);
							if (Target.kind == UniRPG.MapKind.Dungeon) PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0));
							else PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0 || moldingMode));
						} break;

						case ToolTypes.Tiles:
						{
							int y = (int)(cursorPos.z / Target.tileSize);
							int x = (int)(cursorPos.x / Target.tileSize);
							PlaceTile(x, y, Event.current.button == 0);
						} break;

					}

					Event.current.Use(); // so that mouse drags dont move/rotate view in Tool.View mode
				}
				else dragOnGrid = false;
			}

			if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.ignore)
			{
				dragOnGrid = false;
			}

			if (Event.current.type == EventType.scrollWheel && Event.current.control)
			{
				if (Event.current.delta.y < 0f) { forceGuiDirty = true; Target.ed_currentLevel++; Event.current.Use(); }
				if (Event.current.delta.y > 0f) { forceGuiDirty = true; Target.ed_currentLevel--; Event.current.Use(); }
			}

		}

		private void PlaceTile(int x, int y, bool place)
		{
			if (place)
			{
				Target.PlaceTile(x, y, Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, tileReplaceMode, currDir, brushSize, autoTilesSelection, ed_selectedType);

				if (brushSize == 1) HideWireframeFor(Target, x, y);
				else
				{
					int bs = (brushSize / 2);
					int sx = x - bs;
					int sy = y - bs;
					int ex = x + (brushSize - bs);
					int ey = y + (brushSize - bs);
					for (int xx = sx; xx < ex; xx++) for (int yy = sy; yy < ey; yy++) HideWireframeFor(Target, xx, yy);					
				}
			}
			else
			{
				Target.RemoveTile(x,y,brushSize);
			}
		}

		private void PlaceAutoTile(int x, int y, int height, bool place)
		{
			if (place) Target.PlaceAutoTile(x, y, height, ed_selectedSet, ed_selectedTile, brushSize, tileReplaceMode, floorRandomRot, floorRandomTile);
			else Target.RemoveAutoTile(x, y, brushSize, ed_selectedSet);

			if (Target.kind == UniRPG.MapKind.Dungeon || place)
			{
				if (brushSize == 1)
				{
					HideWireframeFor(Target, x, y);
					HideWireframeFor(Target, x, y - 1);
					HideWireframeFor(Target, x, y + 1);
					HideWireframeFor(Target, x - 1, y);
					HideWireframeFor(Target, x - 1, y - 1);
					HideWireframeFor(Target, x - 1, y + 1);
					HideWireframeFor(Target, x + 1, y);
					HideWireframeFor(Target, x + 1, y - 1);
					HideWireframeFor(Target, x + 1, y + 1);
				}

				else
				{
					int bs = (brushSize / 2);
					int sx = x - bs - 2;
					int sy = y - bs - 2;
					int ex = x + (brushSize - bs) + 2;
					int ey = y + (brushSize - bs) + 2;

					for (int xx = sx; xx < ex; xx++)
					{
						for (int yy = sy; yy < ey; yy++)
						{
							HideWireframeFor(Target, xx, yy);
						}
					}
				}
			}

		}

		private void PlacePlop()
		{
			if (Event.current.button != 0) return;
			if (ed_selectedPlopSet == -1 || ed_selectedPlop == -1) return;

			GameObject go = Target.PlacePlop(cursorPos, currDir, ed_selectedPlopSet, ed_selectedPlop);
			if (go) PLYEditorUtil.HideRendererWireframe(go);
		}

		public static void HideWireframeFor(Map map, int x, int y)
		{
			if (x < 0 || y < 0 || x >= map.width || y >= map.length) return;
			int idx = y * map.width + x;
			GameObject go = map.tiles[idx];
			if (go != null)
			{
				PLYEditorUtil.HideRendererWireframe(go);
				TilePiece piece = map.tiles[idx].GetComponent<TilePiece>();
				if (piece.linkedPieces != null)
				{
					foreach (GameObject g in piece.linkedPieces) PLYEditorUtil.HideRendererWireframe(g);
				}
			}
		}

		#endregion
		// ================================================================================================================
	}
}