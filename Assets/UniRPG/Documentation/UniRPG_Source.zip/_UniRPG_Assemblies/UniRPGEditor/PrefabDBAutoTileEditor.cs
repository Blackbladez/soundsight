// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PrefabDBAutoTileEditor
	{
		private DefAutoTileSet activeSet = null;
		private DefAutoTile activeTile = null;
		
		private static Vector2[] scrollPos = { Vector2.zero, Vector2.zero };

		private bool showSetCreate = false;
		private string newset_name = "TileSet";
		private Color newset_color = Color.cyan;
		private bool newset_islower = false;
		private UniRPG.TileSetKind newset_kind = UniRPG.TileSetKind.Terrain;
		private UniRPG.MapKind newset_mapmask = UniRPG.MapKind.Terrain;

		// ================================================================================================================

		public void Render(EditorWindow win)
		{
			EditorGUILayout.BeginHorizontal();
			{
				DrawLeftPanel(win);	// left panel show a list of Sets
				PLYEditorUtil.DrawVerticalLine(2f, PLYEditorUtil.LineColor);
				DrawRightPanel(win);	// the right panel is where the selected set is edited
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawLeftPanel(EditorWindow win)
		{
			EditorGUILayout.BeginVertical(GUILayout.Width(UniRPGEditor.PrefabEdLeftPanelWidth));
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("+ new set", EditorStyles.miniButton, GUILayout.Width(100)))
				{
					showSetCreate = true; newset_islower = false;
					newset_name = "TileSet"; 
					newset_kind = UniRPG.TileSetKind.Terrain;
					newset_mapmask = UniRPG.MapKind.Terrain;
					newset_color = PLYUtil.RandomColor();
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			scrollPos[0] = EditorGUILayout.BeginScrollView(scrollPos[0]);
			{
				if (PrefabDBEditor.db.autoTiles.Count > 0)
				{
					DefAutoTileSet deleteSet = null;
					foreach (DefAutoTileSet set in PrefabDBEditor.db.autoTiles)
					{
						Rect r = EditorGUILayout.BeginHorizontal();
						{
							r.x += 5; r.width = 50; r.height = 14;
							PLYEditorUtil.DrawFilledRect(r, set.editorColor, true, 5f, -15f, 3f);
							if (PLYEditorUtil.ToggleButton(activeSet == set, set.name, EditorStyles.miniButtonLeft))
							{
								activeSet = set;
								activeTile = (activeSet.tiles.Count > 0 ? activeSet.tiles[0] : null);
							}
							if (GUILayout.Button("X", EditorStyles.miniButtonRight, GUILayout.Width(20)))
							{
								if (EditorUtility.DisplayDialog("Delete the Tile Set?", "Are you sure you want to delete this Tile Set?", "Yes", "No"))
								{
									deleteSet = set;
								}
							}
						}
						EditorGUILayout.EndHorizontal();
					}

					// check if a set was chosen to be deleted
					if (deleteSet != null)
					{
						activeSet = null; activeTile = null;
						PrefabDBEditor.db.autoTiles.Remove(deleteSet);
					}

				}
				else
				{
					GUILayout.Label("No tile sets defined", PLYEditorUtil.WarningLabelStyle);
				}
			}

			GUILayout.Space(20);
			EditorGUILayout.EndScrollView();
			EditorGUILayout.EndVertical();
		}

		private void DrawRightPanel(EditorWindow win)
		{
			if (PrefabDBEditor.db.autoTiles.Count == 0)
			{
				activeSet = null;
				showSetCreate = true;
			}

			if (showSetCreate)
			{
				PLYEditorUtil.BeginBox("Create New Tile Set", GUILayout.MaxWidth(300));
				{
					newset_name = EditorGUILayout.TextField("Tile Set Name:", newset_name);
					newset_color = EditorGUILayout.ColorField("Editor Colour:", newset_color);
					newset_kind = (UniRPG.TileSetKind)EditorGUILayout.EnumPopup("Tile Set Kind:", newset_kind);
					if (newset_kind == UniRPG.TileSetKind.Dungeon)
					{
						newset_islower = EditorGUILayout.Toggle("Is Lower Tiles:", newset_islower);
					}
					if (newset_kind == UniRPG.TileSetKind.Expanding)
					{
						newset_mapmask = (UniRPG.MapKind)EditorGUILayout.EnumMaskField("Allowed Maps:", newset_mapmask);
					}
					EditorGUILayout.Space();
					EditorGUILayout.BeginHorizontal();
					{
						if (GUILayout.Button("Create"))
						{
							activeSet = new DefAutoTileSet();
							activeSet.name = newset_name;
							activeSet.editorColor = newset_color;
							activeSet.kind = newset_kind;
							activeSet.isLower = newset_islower;

							if (newset_kind == UniRPG.TileSetKind.Dungeon) activeSet.allowedMapsMask = UniRPG.MapKind.Dungeon;
							else if (newset_kind == UniRPG.TileSetKind.Terrain) activeSet.allowedMapsMask = UniRPG.MapKind.Terrain;
							else activeSet.allowedMapsMask = newset_mapmask;

							PrefabDBEditor.db.autoTiles.Add(activeSet);
							showSetCreate = false;
						}
						if (GUILayout.Button("Cancel", GUILayout.Width(100)))
						{
							showSetCreate = false;
						}
					}
					EditorGUILayout.EndHorizontal();
				}
				PLYEditorUtil.EndBox();
				return;
			}

			if (activeSet == null) return;

			if (activeSet.kind != UniRPG.TileSetKind.Dungeon && activeSet.kind != UniRPG.TileSetKind.Terrain && activeSet.kind != UniRPG.TileSetKind.Expanding)
			{
				GUILayout.Label("Auto-Tiles does not support this Kind (" + activeSet.kind + ")", PLYEditorUtil.WarningLabelStyle);
				return;
			}

			scrollPos[1] = EditorGUILayout.BeginScrollView(scrollPos[1]);

			// show set info and options
			EditorGUILayout.BeginHorizontal(GUILayout.ExpandWidth(true));
			{
				PLYEditorUtil.BeginBox("Tile Set Info", GUILayout.MaxWidth(300));
				{
					activeSet.name = EditorGUILayout.TextField("Tile Set Name:", activeSet.name);
					activeSet.editorColor = EditorGUILayout.ColorField("Editor Colour:", activeSet.editorColor);
					EditorGUILayout.LabelField("Tile Set Kind:", activeSet.kind.ToString());
					if (activeSet.kind == UniRPG.TileSetKind.Dungeon)
					{
						activeSet.isLower = EditorGUILayout.Toggle("Is Lower Tiles:", activeSet.isLower);
					}
					if (activeSet.kind == UniRPG.TileSetKind.Expanding)
					{
						activeSet.allowedMapsMask = (UniRPG.MapKind)EditorGUILayout.EnumMaskField("Allowed Maps:", activeSet.allowedMapsMask);
					}
				}
				PLYEditorUtil.EndBox();

				EditorGUILayout.BeginVertical();
				{

					if (GUILayout.Button("Add New Tile", GUILayout.Width(150)))
					{
						activeTile = null;
						if (activeSet.kind == UniRPG.TileSetKind.Dungeon) activeTile = new DefAutoTile(DefAutoTile.DUNGEON_MAX_PIECES);
						else if (activeSet.kind == UniRPG.TileSetKind.Terrain) activeTile = new DefAutoTile(DefAutoTile.TERRAIN_MAX_PIECES);
						else if (activeSet.kind == UniRPG.TileSetKind.Expanding) activeTile = new DefAutoTile(DefAutoTile.EXPANDING_MAX_PIECES);
						if (activeTile != null) activeSet.tiles.Add(activeTile);
					}

					if (activeTile == null) GUI.enabled = false;

					if (GUILayout.Button("Clone Tile", GUILayout.Width(150)))
					{
						DefAutoTile t = activeTile;
						activeTile = t.Clone();
						activeSet.tiles.Add(activeTile);
					}

					if (GUILayout.Button("Delete Tile", GUILayout.Width(150)))
					{
						if (EditorUtility.DisplayDialog("Delete the Tile?", "Are you sure you want to delete this Tile?", "Yes", "No"))
						{
							activeSet.tiles.Remove(activeTile);
							activeTile = (activeSet.tiles.Count > 0 ? activeSet.tiles[0] : null);
						}
					}
					GUI.enabled = true;
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			// show list of tiles
			DrawTileSetSelectionBar(ref activeSet, ref activeTile);

			// show tile editor
			switch (activeSet.kind)
			{
				case UniRPG.TileSetKind.Dungeon: DrawDungeonAutoTileEditor(win); break;
				case UniRPG.TileSetKind.Terrain: DrawTerrainAutoTileEditor(win); break;
				case UniRPG.TileSetKind.Expanding: DrawExpandingAutoTileEditor(win); break;
			}

			EditorGUILayout.EndScrollView();
		}

		// ************

		private void DrawTileSetSelectionBar(ref DefAutoTileSet selectedSet, ref DefAutoTile selectedTile, int forceColumnCount = 0, bool ratherShowWall = false)
		{
			GUILayout.Space(5);
			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height;

			if (forceColumnCount == 0)
			{
				r.width = Screen.width - UniRPGEditor.PrefabEdLeftPanelWidth - 24f;
			}

			int columns = Mathf.FloorToInt(r.width / (64f + UniRPGEditor.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			if (forceColumnCount > 0) columns = forceColumnCount;
			int rows = Mathf.CeilToInt(selectedSet.tiles.Count / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom)) + 4;

			r = GUILayoutUtility.GetRect(r.width, r.height);

			r.x += 4; r.width -= 20f;
			GUI.Box(r, GUIContent.none);

			r.x += 3; r.y += 3;
			if (selectedSet.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;
				float startX = r.x;
				bool wasFine = false;

				// show the buttons for selection of tile variations in this set
				foreach (DefAutoTile tile in selectedSet.tiles)
				{
					if (tile.pieces[(int)TilePiece.Kind.Floor] != null)
					{
						TilePiece p = null;
						if (ratherShowWall && tile.pieces[(int)TilePiece.Kind.Wall] != null) p = tile.pieces[(int)TilePiece.Kind.Wall].GetComponent<TilePiece>();
						if (p == null) p = tile.pieces[(int)TilePiece.Kind.Floor].GetComponent<TilePiece>();
						if (p != null)
						{
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, (selectedTile == tile), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle)) selectedTile = tile;
						}
						else
						{
							if (PLYEditorUtil.ActiveButton(r, null, (selectedTile == tile), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle)) selectedTile = tile;
						}
					}
					else
					{
						if (PLYEditorUtil.ActiveButton(r, null, (selectedTile == tile), UniRPGEditor.IconToggleButtonOffStyle, UniRPGEditor.IconToggleButtonOnStyle)) selectedTile = tile;
					}

					column++; r.x += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.right;
					if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditor.IconToggleButtonOffStyle.margin.bottom; }

					if (selectedTile == tile) wasFine = true;
				}

				if (!wasFine && selectedTile != null)
				{	// the active tile is not null, but also not one of the visible tiles, not good
					selectedTile = null;
				}
			}

			else
			{
				GUI.Label(r, "No tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
				selectedTile = null; // just to be sure it is null cause some gui rendering checks for it
			}
		}

		private void DrawDungeonAutoTileEditor(EditorWindow win)
		{
			if (activeTile == null) return;
			bool err = false;

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(false));
				{
					EditorGUILayout.BeginHorizontal();
					{
						if (!DrawTilePieceInfo("Floor", UniRPGEditor.TileIcon_Floor, ref activeTile.pieces[(int)TilePiece.Kind.Floor]))
						{
							err = true; activeTile.pieces[(int)TilePiece.Kind.Floor] = null;
						}
						if (!DrawTilePieceInfo("Wall", UniRPGEditor.TileIcon_Wall, ref activeTile.pieces[(int)TilePiece.Kind.Wall]))
						{
							err = true;  activeTile.pieces[(int)TilePiece.Kind.Wall] = null;
						}
						if (!DrawTilePieceInfo("Pillar", UniRPGEditor.TileIcon_Pillar, ref activeTile.pieces[(int)TilePiece.Kind.Pillar]))
						{
							err = true; activeTile.pieces[(int)TilePiece.Kind.Pillar] = null;
						}
					}
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.BeginHorizontal();
					{
						if (!DrawTilePieceInfo("Corner1", UniRPGEditor.TileIcon_Corner1, ref activeTile.pieces[(int)TilePiece.Kind.Corner1]))
						{
							err = true; activeTile.pieces[(int)TilePiece.Kind.Corner1] = null;
						}
						if (!DrawTilePieceInfo("Corner2", UniRPGEditor.TileIcon_Corner2, ref activeTile.pieces[(int)TilePiece.Kind.Corner2]))
						{
							err = true; activeTile.pieces[(int)TilePiece.Kind.Corner2] = null;
						}
						if (!DrawTilePieceInfo("Corner3", UniRPGEditor.TileIcon_Corner3, ref activeTile.pieces[(int)TilePiece.Kind.Corner3]))
						{
							err = true; activeTile.pieces[(int)TilePiece.Kind.Corner3] = null;
						}
					}
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.EndVertical();

				if (activeSet.isLower)
				{
					EditorGUILayout.BeginVertical(PLYEditorUtil.BoxStyle, GUILayout.MinWidth(230));
					{
						GUILayout.Label("Makes use of upper wall?", EditorStyles.boldLabel);
						EditorGUILayout.Space();

						// calc which sets can be used
						int selected = 0, counter = 0;
						List<string> names = new List<string>();
						names.Add("No, does not apply");
						for (int i = 0; i < PrefabDBEditor.db.autoTiles.Count; i++)
						{
							if (PrefabDBEditor.db.autoTiles[i].kind == activeSet.kind)
							{
								names.Add(PrefabDBEditor.db.autoTiles[i].name);
								counter++;
							}
							if (activeTile.upperSet == i) selected = counter;
						}

						// show list of sets that can be used
						selected = EditorGUILayout.Popup(selected, names.ToArray());

						// figure out which set was chosen
						if (selected == 0) activeTile.upperSet = -1;
						else
						{
							counter = 0;
							for (int i = 0; i < PrefabDBEditor.db.autoTiles.Count; i++)
							{
								if (PrefabDBEditor.db.autoTiles[i].kind == activeSet.kind) counter++;
								if (selected == counter)
								{
									activeTile.upperSet = i;
									break;
								}
							}
						}

						if (activeTile.upperSet >= 0)
						{
							if (activeTile.upperTile >= PrefabDBEditor.db.autoTiles[activeTile.upperSet].tiles.Count) activeTile.upperTile = PrefabDBEditor.db.autoTiles[activeTile.upperSet].tiles.Count - 1;
							EditorGUILayout.Space();
							GUILayout.Label("Auto-Tile to use: ");
							DefAutoTileSet aSet = PrefabDBEditor.db.autoTiles[activeTile.upperSet];
							DefAutoTile aTile = (activeTile.upperTile >= 0 ? PrefabDBEditor.db.autoTiles[activeTile.upperSet].tiles[activeTile.upperTile] : null);
							DrawTileSetSelectionBar(ref aSet, ref aTile, 3, true);
							// find out which tile was chosen
							for (int i = 0; i < PrefabDBEditor.db.autoTiles[activeTile.upperSet].tiles.Count; i++)
							{
								if (PrefabDBEditor.db.autoTiles[activeTile.upperSet].tiles[i] == aTile)
								{
									activeTile.upperTile = i;
									break;
								}
							}
						}

					}
					EditorGUILayout.EndVertical();
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			if (err) win.ShowNotification(new GUIContent("Not a valid TilePiece Prefab"));
		}

		private void DrawTerrainAutoTileEditor(EditorWindow win)
		{
			if (activeTile == null) return;
			bool err = false;

			EditorGUILayout.Space();

			EditorGUILayout.BeginHorizontal();
			{
				if (!DrawTilePieceInfo("Floor", UniRPGEditor.TileIcon_Floor, ref activeTile.pieces[(int)TilePiece.Kind.Floor]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Floor] = null;
				}
				if (!DrawTilePieceInfo("Wall", UniRPGEditor.TileIcon_TerrainWall, ref activeTile.pieces[(int)TilePiece.Kind.Wall]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Wall] = null;
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				if (!DrawTilePieceInfo("Corner1", UniRPGEditor.TileIcon_TerrainCorner1, ref activeTile.pieces[(int)TilePiece.Kind.Corner1]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Corner1] = null;
				}
				if (!DrawTilePieceInfo("Corner2", UniRPGEditor.TileIcon_TerrainCorner2, ref activeTile.pieces[(int)TilePiece.Kind.Corner2]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Corner2] = null;
				}
			}
			EditorGUILayout.EndHorizontal();

			if (err) win.ShowNotification(new GUIContent("Not a valid TilePiece Prefab"));
		}

		private void DrawExpandingAutoTileEditor(EditorWindow win)
		{
			if (activeTile == null) return;
			bool err = false;

			EditorGUILayout.Space();

			GUILayout.Label("These are needed to create continues path like layouts");
			EditorGUILayout.BeginHorizontal();
			{
				if (!DrawTilePieceInfo("Single", UniRPGEditor.TileIcon_Ex_Single, ref activeTile.pieces[(int)TilePiece.Kind.Single]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Single] = null;
				}
				if (!DrawTilePieceInfo("Sides", UniRPGEditor.TileIcon_Ex_Sides, ref activeTile.pieces[(int)TilePiece.Kind.Sides]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Sides] = null;
				}
				if (!DrawTilePieceInfo("End", UniRPGEditor.TileIcon_Ex_End, ref activeTile.pieces[(int)TilePiece.Kind.Dead_End]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Dead_End] = null;
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				if (!DrawTilePieceInfo("Corner", UniRPGEditor.TileIcon_Ex_Corner1, ref activeTile.pieces[(int)TilePiece.Kind.Corner1]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Corner1] = null;
				}
				if (!DrawTilePieceInfo("Junction", UniRPGEditor.TileIcon_Ex_Junction1, ref activeTile.pieces[(int)TilePiece.Kind.Junction1]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Junction1] = null;
				}
				if (!DrawTilePieceInfo("Crossing", UniRPGEditor.TileIcon_Ex_Crossing1, ref activeTile.pieces[(int)TilePiece.Kind.Crossing1]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Crossing1] = null;
				}
			}
			EditorGUILayout.EndHorizontal();
			
			EditorGUILayout.Space();
			GUILayout.Label("These are needed to create expanding patches (optional)");
			EditorGUILayout.BeginHorizontal();
			{
				if (!DrawTilePieceInfo("Full", UniRPGEditor.TileIcon_Ex_Full, ref activeTile.pieces[(int)TilePiece.Kind.Full]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Full] = null;
				}
				if (!DrawTilePieceInfo("One Side", UniRPGEditor.TileIcon_Ex_One_Side, ref activeTile.pieces[(int)TilePiece.Kind.One_Side]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.One_Side] = null;
				}
				if (!DrawTilePieceInfo("Corner2", UniRPGEditor.TileIcon_Ex_Corner2, ref activeTile.pieces[(int)TilePiece.Kind.Corner2]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Corner2] = null;
				}
				if (!DrawTilePieceInfo("Junction2", UniRPGEditor.TileIcon_Ex_Junction2, ref activeTile.pieces[(int)TilePiece.Kind.Junction2]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Junction2] = null;
				}
				if (!DrawTilePieceInfo("Junction3", UniRPGEditor.TileIcon_Ex_Junction3, ref activeTile.pieces[(int)TilePiece.Kind.Junction3]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Junction3] = null;
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Crossing", GUILayout.ExpandWidth(false), GUILayout.Width(106));
				if (!DrawTilePieceInfo("- 2", UniRPGEditor.TileIcon_Ex_Crossing2, ref activeTile.pieces[(int)TilePiece.Kind.Crossing2]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Crossing2] = null;
				}
				if (!DrawTilePieceInfo("- 3", UniRPGEditor.TileIcon_Ex_Crossing3, ref activeTile.pieces[(int)TilePiece.Kind.Crossing3]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Crossing3] = null;
				}
				if (!DrawTilePieceInfo("- 4", UniRPGEditor.TileIcon_Ex_Crossing4, ref activeTile.pieces[(int)TilePiece.Kind.Crossing4]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Crossing4] = null;
				}
				if (!DrawTilePieceInfo("- 5", UniRPGEditor.TileIcon_Ex_Crossing5, ref activeTile.pieces[(int)TilePiece.Kind.Crossing5]))
				{
					err = true; activeTile.pieces[(int)TilePiece.Kind.Crossing5] = null;
				}
			}
			EditorGUILayout.EndHorizontal();

			if (err) win.ShowNotification(new GUIContent("Not a valid TilePiece Prefab"));
		}

		private bool DrawTilePieceInfo(string name, Texture2D icon, ref GameObject tilePiece)
		{
			bool ret = true; // if return false then it means the tile was invalid and did not have TilePiece component

			EditorGUILayout.BeginVertical(PLYEditorUtil.BoxStyle, GUILayout.Width(100));
			{
				Rect r;
				EditorGUILayout.BeginHorizontal();
				{
					// draw icon
					r = GUILayoutUtility.GetRect(32, 32, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false));
					GUI.DrawTexture(r, icon);

					EditorGUILayout.BeginVertical();
					{
						// label
						GUILayout.Label(name, PLYEditorUtil.BoldLabelStyle);
						// field to change gameobject
						tilePiece = (GameObject)EditorGUILayout.ObjectField(tilePiece, typeof(GameObject), false);
					}
					EditorGUILayout.EndVertical();
				}
				EditorGUILayout.EndHorizontal();

				// preview of the piece
				r = GUILayoutUtility.GetRect(100, 105, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false));
				r.height = 100; r.y += 5;
				bool err = true;
				if (tilePiece != null)
				{
					TilePiece p = tilePiece.GetComponent<TilePiece>();
					if (p != null)
					{
						if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
						if (p._preview != null)
						{
							err = false;
							GUI.DrawTexture(r, p._preview);
						}
					}
					else
					{
						// error, this was not a valid TilePiece
						ret = false;
					}
				}

				if (err) GUI.Box(r, GUIContent.none);
			}
			EditorGUILayout.EndVertical();

			return ret;
		}

		// ================================================================================================================
	}
}